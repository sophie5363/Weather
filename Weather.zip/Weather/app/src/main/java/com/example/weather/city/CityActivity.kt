package com.example.weather.city

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.weather.R

class CityActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_city)



    }
}

